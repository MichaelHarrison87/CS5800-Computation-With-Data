public class LeapYear { 
   public static void main(String[] args) { 
      int year = Integer.parseInt(args[0]); 
      boolean isLeapYear; 
 
      // divisible by 4 but not 100 
      isLeapYear = 
       
      // or divisible by 400 
      isLeapYear = 
 
      System.out.println(isLeapYear); 
   } 
} 