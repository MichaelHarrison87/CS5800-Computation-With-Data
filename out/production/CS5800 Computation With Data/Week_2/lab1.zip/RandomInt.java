public class RandomInt { 
   public static void main(String[] args) { 
      int N = Integer.parseInt(args[0]); 
      
      double r = Math.random(); // generates a random number between 0.0 (inclusive) and 1.0 (exclusive)
      
      int n = 
 
 
 
      System.out.println("random integer is " + n); 
   } 
}  
